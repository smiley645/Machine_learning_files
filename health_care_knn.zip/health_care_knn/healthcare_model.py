import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

df = pd.read_csv("preprocessed_dataset_final.csv")

# Separate features and target variable
X = df.drop('Target', axis=1)   
Y = df['Target']

# Split the dataset
X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y,
    test_size=0.2,
    random_state=42
)

# Feature Scaling 
scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# ===== INSERT CROSS VALIDATION CODE FOR FINDING THE BEST K VALUE =====
from sklearn.model_selection import cross_val_score
import numpy as np

k_values = range(1, 101)
cv_scores = []

for k in k_values:
    knn = KNeighborsClassifier(n_neighbors=k)

    scores = cross_val_score(
        knn,
        X_train,
        Y_train,
        cv=5,
        scoring='accuracy'
    )

    cv_scores.append(scores.mean())

best_k = k_values[np.argmax(cv_scores)]

print("Best K:", best_k)
print("Best Cross Validation Accuracy:", max(cv_scores))

#===== END OF CROSS VALIDATION   =====

# Create KNN model
knn = KNeighborsClassifier(n_neighbors=best_k)


# Train the model
knn.fit(X_train, Y_train)

# Make predictions
Y_pred = knn.predict(X_test)

from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    roc_auc_score
)

#Accuracy
print("Accuracy:", accuracy_score(Y_test, Y_pred))

# Confusion Matrix
print("\nConfusion Matrix:")
print(confusion_matrix(Y_test, Y_pred))

# Precision, Recall, F1-score
print("\nClassification Report:")
print(classification_report(Y_test, Y_pred))